package com.example.meidcare

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class doctorbook : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_doctorbook)

        // Apply Window Insets for edge-to-edge layout
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Get the bookingButton and set an OnClickListener
        val bookingButton: Button = findViewById(R.id.bookingButton)
        bookingButton.setOnClickListener {
            // Navigate to the PaymentActivity
            val intent = Intent(this, payment::class.java)
            startActivity(intent)
        }

        // Get the backButton and set an OnClickListener
        val backButton: ImageButton = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            // Navigate to HomeActivity
            val intent = Intent(this, Home::class.java)
            startActivity(intent)
            finish() // Optional: Finish the current activity to remove it from the back stack
        }
    }
}
