package com.example.meidcare

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.imageview.ShapeableImageView

class Home : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home)

        // Apply window insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Set up click listener for profileImageView
        val profileImageView = findViewById<ShapeableImageView>(R.id.profileImageView)
        profileImageView.setOnClickListener {
            // Navigate to ProfileActivity
            val intent = Intent(this, profile::class.java)
            startActivity(intent)
        }

        // Set up click listener for Book Appointment button
        val bookAppointmentButton = findViewById<Button>(R.id.bookAppointmentButton)
        bookAppointmentButton.setOnClickListener {
            // Navigate to DoctorBookingActivity
            val intent = Intent(this, doctorbook::class.java)
            startActivity(intent)
        }
    }
}